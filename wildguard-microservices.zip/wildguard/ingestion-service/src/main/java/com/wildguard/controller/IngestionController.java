package com.wildguard.controller;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Ingestion Service — equivalente a AWS Kinesis + Firehose.
 * Recibe eventos del Sensor Simulator y los almacena en capa Bronze (en memoria).
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/ingest")
@CrossOrigin(origins = "*")
public class IngestionController {

    private final AtomicLong totalReceived = new AtomicLong(0);
    private final AtomicLong totalRejected = new AtomicLong(0);
    // Buffer en memoria (simula S3 Bronze Layer)
    private final List<Map<String, Object>> bronzeBuffer = new CopyOnWriteArrayList<>();
    private static final int MAX_BUFFER = 10_000;

    /**
     * POST /api/v1/ingest/batch
     * Recibe un batch de lecturas de sensores (simulando Kinesis Data Stream).
     */
    @PostMapping("/batch")
    public ResponseEntity<Map<String, Object>> ingestBatch(@RequestBody List<JsonNode> readings) {
        if (readings == null || readings.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Batch vacío"));
        }

        int accepted = 0;
        int rejected = 0;
        List<String> errors = new ArrayList<>();

        for (JsonNode reading : readings) {
            if (validateReading(reading, errors)) {
                Map<String, Object> record = new LinkedHashMap<>();
                record.put("_ingested_at", Instant.now().toString());
                record.put("_layer", "BRONZE");
                record.put("_shard", "shard-" + (totalReceived.get() % 6));
                record.put("data", reading);

                if (bronzeBuffer.size() < MAX_BUFFER) {
                    bronzeBuffer.add(record);
                }
                accepted++;
                totalReceived.incrementAndGet();
            } else {
                rejected++;
                totalRejected.incrementAndGet();
            }
        }

        log.info("[Kinesis] Batch recibido: {} aceptados, {} rechazados", accepted, rejected);

        return ResponseEntity.ok(Map.of(
                "accepted", accepted,
                "rejected", rejected,
                "errors",   errors,
                "bufferSize", bronzeBuffer.size(),
                "shardOffset", totalReceived.get()
        ));
    }

    /**
     * POST /api/v1/ingest/single
     * Recibe un único evento.
     */
    @PostMapping("/single")
    public ResponseEntity<Map<String, Object>> ingestSingle(@RequestBody JsonNode reading) {
        return ingestBatch(List.of(reading));
    }

    /**
     * GET /api/v1/ingest/bronze?limit=50
     * Consulta los últimos registros en la capa Bronze.
     */
    @GetMapping("/bronze")
    public ResponseEntity<Map<String, Object>> getBronze(
            @RequestParam(defaultValue = "50") int limit) {
        int size = bronzeBuffer.size();
        int from = Math.max(0, size - Math.min(limit, size));
        List<Map<String, Object>> slice = bronzeBuffer.subList(from, size);
        return ResponseEntity.ok(Map.of(
                "layer", "BRONZE",
                "total", size,
                "returned", slice.size(),
                "records", slice
        ));
    }

    /**
     * GET /api/v1/ingest/metrics
     */
    @GetMapping("/metrics")
    public ResponseEntity<Map<String, Object>> metrics() {
        long total = totalReceived.get();
        long rej   = totalRejected.get();
        return ResponseEntity.ok(Map.of(
                "totalReceived",   total,
                "totalRejected",   rej,
                "totalAccepted",   total - rej,
                "acceptanceRate",  total > 0 ? String.format("%.2f%%", (total - rej) * 100.0 / total) : "N/A",
                "bronzeBufferSize", bronzeBuffer.size()
        ));
    }

    /**
     * DELETE /api/v1/ingest/bronze/flush
     * Vacía el buffer Bronze (simula lifecycle a Glacier).
     */
    @DeleteMapping("/bronze/flush")
    public ResponseEntity<Map<String, Object>> flush() {
        int cleared = bronzeBuffer.size();
        bronzeBuffer.clear();
        log.info("[Firehose] Buffer Bronze vaciado: {} registros movidos a Glacier (simulado)", cleared);
        return ResponseEntity.ok(Map.of("flushed", cleared, "status", "moved_to_glacier"));
    }

    private boolean validateReading(JsonNode node, List<String> errors) {
        if (node == null || node.isNull()) {
            errors.add("Nodo nulo");
            return false;
        }
        if (!node.has("deviceId") || node.get("deviceId").isNull()) {
            errors.add("Campo requerido ausente: deviceId");
            return false;
        }
        if (!node.has("temperature") || node.get("temperature").isNull()) {
            errors.add("Campo requerido ausente: temperature");
            return false;
        }
        if (!node.has("timestamp") || node.get("timestamp").isNull()) {
            errors.add("Campo requerido ausente: timestamp");
            return false;
        }
        // Validación de rango de temperatura
        double temp = node.get("temperature").asDouble();
        if (temp < -50 || temp > 200) {
            errors.add("Temperatura fuera de rango: " + temp);
            return false;
        }
        return true;
    }
}
