# WildGuard — Sistema de Microservicios para Detección de Incendios Forestales

Proyecto Spring Boot multi-módulo que implementa el pipeline de datos del documento de arquitectura WildGuard, con conexión real a la API climática **Open-Meteo** (gratuita, sin clave).

---

## Arquitectura de Microservicios

```
Open-Meteo API (datos climáticos reales)
        ↓
┌─────────────────────┐     ┌──────────────────────┐
│  sensor-simulator   │────▶│  ingestion-service   │
│  Puerto: 8080       │     │  Puerto: 8081         │
│  (IoT + Open-Meteo) │     │  (Kinesis / Firehose) │
└─────────────────────┘     └──────────┬───────────┘
                                        │
                            ┌──────────▼───────────┐
                            │  validation-service  │
                            │  Puerto: 8082         │
                            │  (Lambda / Bronze→Silver)│
                            └──────────┬───────────┘
                                        │
                            ┌──────────▼───────────┐
                            │   alert-service      │
                            │   Puerto: 8083        │
                            │   (SageMaker + SNS)   │
                            └──────────────────────┘
                                        ↑
                            ┌──────────────────────┐
                            │    api-gateway       │
                            │    Puerto: 8090       │
                            │    (punto de entrada) │
                            └──────────────────────┘
```

---

## Requisitos

- **Java 21** (JDK 21+)
- **Maven 3.9+**
- **IntelliJ IDEA** (recomendado: Ultimate o Community con plugin Spring)
- Conexión a internet (para Open-Meteo API)

---

## Cómo abrir en IntelliJ

1. `File → Open` y seleccionar la carpeta `wildguard/`
2. IntelliJ detectará automáticamente el `pom.xml` raíz (multi-módulo Maven)
3. Hacer clic en **"Trust Project"** si se solicita
4. Esperar que Maven descargue dependencias (primer inicio puede tardar ~2 min)
5. Cada módulo tiene su propia clase `*Application.java` como punto de entrada

---

## Cómo ejecutar

### Opción A — Desde IntelliJ (recomendado para pruebas)

Ejecutar cada `*Application.java` en orden:
1. `SensorSimulatorApplication`  (puerto 8080)
2. `IngestionServiceApplication` (puerto 8081)
3. `ValidationServiceApplication` (puerto 8082)
4. `AlertServiceApplication`     (puerto 8083)
5. `ApiGatewayApplication`       (puerto 8090) — opcional

### Opción B — Maven desde terminal

```bash
# Compilar todo el proyecto
mvn clean install -DskipTests

# Ejecutar cada servicio (terminales separadas)
cd sensor-simulator  && mvn spring-boot:run
cd ingestion-service && mvn spring-boot:run
cd validation-service&& mvn spring-boot:run
cd alert-service     && mvn spring-boot:run
cd api-gateway       && mvn spring-boot:run
```

---

## Endpoints — Sensor Simulator (puerto 8080)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/v1/simulator/health` | Health check |
| GET | `/api/v1/simulator/generate?count=10` | Genera N lecturas con Open-Meteo |
| GET | `/api/v1/simulator/generate/single` | Genera 1 lectura |
| GET | `/api/v1/simulator/metrics` | Métricas del simulador |

**Ejemplo de respuesta** (`/generate/single`):
```json
{
  "deviceId": "SNS-RLC-001",
  "zone": "Zona Metropolitana",
  "reserva": "Reserva Río Clarillo",
  "temperature": 38.45,
  "humidity": 28.3,
  "co2Ppm": 612.4,
  "windSpeedMs": 12.7,
  "gpsHashId": "GPS_4F2A8B1C9E3D7F0A",
  "weatherTemp": 34.2,
  "weatherHumidity": 32.0,
  "weatherWindSpeed": 8.5,
  "weatherPrecipitation": 0.0,
  "weatherCode": 0,
  "weatherDescription": "Cielo despejado",
  "riskLevel": "HIGH",
  "riskScore": 0.71,
  "anomalyDetected": false,
  "layer": "BRONZE"
}
```

---

## Endpoints — Ingestion Service (puerto 8081)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/api/v1/ingest/batch` | Recibe batch de eventos (Bronze) |
| POST | `/api/v1/ingest/single` | Recibe 1 evento |
| GET | `/api/v1/ingest/bronze?limit=50` | Consulta capa Bronze |
| GET | `/api/v1/ingest/metrics` | Métricas de ingesta |
| DELETE | `/api/v1/ingest/bronze/flush` | Vacía buffer (→ Glacier) |

---

## Endpoints — Validation Service (puerto 8082)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/api/v1/validate/process` | Bronze → Silver (valida + pseudonimiza) |
| GET | `/api/v1/validate/metrics` | Tasa de validación |

---

## Endpoints — Alert Service (puerto 8083)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/api/v1/alerts/evaluate` | Evalúa un evento Silver |
| GET | `/api/v1/alerts/active` | Alertas activas |
| GET | `/api/v1/alerts/history?limit=100` | Historial de alertas |
| GET | `/api/v1/alerts/dashboard` | KPIs Gold Layer |
| DELETE | `/api/v1/alerts/active/{deviceId}` | Resolver alerta |

---

## Endpoints — API Gateway (puerto 8090)

El gateway enruta todas las rutas con prefijo:

```
http://localhost:8090/simulator/api/v1/simulator/generate
http://localhost:8090/ingest/api/v1/ingest/bronze
http://localhost:8090/validate/api/v1/validate/metrics
http://localhost:8090/alerts/api/v1/alerts/dashboard
```

---

## Configuración del Simulador

Editar `sensor-simulator/src/main/resources/application.yml`:

```yaml
wildguard:
  simulator:
    enabled: true
    sensors-per-tick: 5      # sensores por ciclo
    interval-ms: 5000        # cada 5 segundos
  ingestion:
    url: http://localhost:8081
```

---

## Pruebas rápidas con curl

```bash
# 1. Generar 3 lecturas con clima real
curl http://localhost:8080/api/v1/simulator/generate?count=3 | jq .

# 2. Ver métricas del simulador
curl http://localhost:8080/api/v1/simulator/metrics | jq .

# 3. Ver alertas activas
curl http://localhost:8083/api/v1/alerts/active | jq .

# 4. Ver KPIs del dashboard
curl http://localhost:8083/api/v1/alerts/dashboard | jq .

# 5. Enviar evento al pipeline completo
EVENTO=$(curl -s http://localhost:8080/api/v1/simulator/generate/single)
echo $EVENTO | curl -s -X POST http://localhost:8081/api/v1/ingest/single \
  -H "Content-Type: application/json" -d @-
```

---

## API Open-Meteo

- **URL base**: `https://api.open-meteo.com/v1/forecast`
- **Sin API key** — completamente gratuita
- **Docs**: https://open-meteo.com/en/docs
- **Variables usadas**: `temperature_2m`, `relative_humidity_2m`, `apparent_temperature`, `precipitation`, `weather_code`, `wind_speed_10m`, `wind_direction_10m`, `soil_moisture_0_to_1cm`
- **Caché local**: 10 minutos por zona (evita rate limiting)

---

## Estructura del proyecto

```
wildguard/
├── pom.xml                          ← raíz multi-módulo
├── sensor-simulator/                ← puerto 8080
│   └── src/main/java/com/wildguard/
│       ├── SensorSimulatorApplication.java
│       ├── model/
│       │   ├── SensorReading.java   ← modelo IoT completo
│       │   └── OpenMeteoResponse.java
│       ├── service/
│       │   ├── OpenMeteoClient.java ← cliente API clima
│       │   ├── SensorSimulatorService.java
│       │   ├── RiskCalculator.java  ← índice FWI simplificado
│       │   └── WeatherCodeMapper.java
│       ├── scheduler/
│       │   └── SensorScheduler.java ← emisión automática
│       └── config/
│           └── SensorController.java
├── ingestion-service/               ← puerto 8081 (Kinesis)
├── validation-service/              ← puerto 8082 (Lambda)
├── alert-service/                   ← puerto 8083 (SNS/SageMaker)
└── api-gateway/                     ← puerto 8090 (API Gateway)
```

---

## Notas de diseño

- **Pseudonimización GPS**: las coordenadas reales solo existen en capa BRONZE. La capa SILVER usa un hash SHA-256+salt (`GPS_XXXXXXXXXXXXXXXX`), cumpliendo GDPR.
- **Caché climática**: Open-Meteo se consulta máximo una vez cada 10 minutos por reserva para respetar los límites de la API gratuita.
- **Riesgo de incendio**: calculado con FWI simplificado combinando datos del sensor (70%) + datos climáticos Open-Meteo (30%).
- **5% de probabilidad** de simular condición de incendio en cada tick para probar las alertas.
