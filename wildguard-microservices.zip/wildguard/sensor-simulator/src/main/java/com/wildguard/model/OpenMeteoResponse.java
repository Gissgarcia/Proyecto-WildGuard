package com.wildguard.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Modelo de respuesta de la API Open-Meteo (https://api.open-meteo.com).
 * API gratuita, sin clave, con datos horarios/actuales de clima.
 *
 * Endpoint usado:
 *   GET https://api.open-meteo.com/v1/forecast
 *     ?latitude={lat}&longitude={lon}
 *     &current=temperature_2m,relative_humidity_2m,apparent_temperature,
 *              precipitation,weather_code,wind_speed_10m,wind_direction_10m,
 *              soil_moisture_0_to_1cm
 *     &timezone=America/Santiago
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class OpenMeteoResponse {

    private Double latitude;
    private Double longitude;

    @JsonProperty("current")
    private CurrentWeather current;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CurrentWeather {

        @JsonProperty("temperature_2m")
        private Double temperature2m;

        @JsonProperty("relative_humidity_2m")
        private Integer relativeHumidity2m;

        @JsonProperty("apparent_temperature")
        private Double apparentTemperature;

        @JsonProperty("precipitation")
        private Double precipitation;

        @JsonProperty("weather_code")
        private Integer weatherCode;

        @JsonProperty("wind_speed_10m")
        private Double windSpeed10m;

        @JsonProperty("wind_direction_10m")
        private Double windDirection10m;

        @JsonProperty("soil_moisture_0_to_1cm")
        private Double soilMoisture0to1cm;
    }
}
