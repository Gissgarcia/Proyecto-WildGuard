package com.wildguard.service;

import com.wildguard.model.OpenMeteoResponse;
import com.wildguard.model.SensorReading;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Servicio principal que:
 * 1. Genera lecturas simuladas de sensores IoT
 * 2. Las enriquece con datos reales de Open-Meteo
 * 3. Calcula el riesgo de incendio
 * 4. Aplica pseudonimización GPS (capa Silver)
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SensorSimulatorService {

    private final OpenMeteoClient openMeteoClient;
    private final RiskCalculator riskCalculator;
    private final WeatherCodeMapper weatherCodeMapper;

    // Cache de clima para evitar llamadas excesivas (por zona)
    private final Map<String, CachedWeather> weatherCache = new ConcurrentHashMap<>();
    private static final long CACHE_TTL_MS = 10 * 60 * 1000L; // 10 minutos

    // Métricas internas
    private final AtomicLong totalGenerated = new AtomicLong(0);
    private final AtomicLong totalAlertas = new AtomicLong(0);
    private final List<Long> latencies = Collections.synchronizedList(new ArrayList<>());

    // --- Definición de reservas y zonas (Chile) ---
    private static final List<ReservaConfig> RESERVAS = List.of(
        new ReservaConfig("Reserva Lago Peñuelas",  "Zona Valparaíso",  -33.1667, -71.5500),
        new ReservaConfig("Reserva Río Clarillo",   "Zona Metropolitana", -33.7833, -70.5167),
        new ReservaConfig("Reserva Lago Torca",     "Zona Maule",       -35.2667, -72.1500),
        new ReservaConfig("Reserva Altos de Lircay","Zona Maule",       -35.5833, -71.1667),
        new ReservaConfig("Reserva Los Queules",    "Zona Biobío",      -35.9833, -72.6667),
        new ReservaConfig("Reserva Laguna Torca",   "Zona Biobío",      -35.2500, -72.1333),
        new ReservaConfig("Reserva Nonguén",        "Zona Biobío",      -36.9833, -72.9333),
        new ReservaConfig("Reserva Los Ruiles",     "Zona Maule",       -35.9000, -72.6000)
    );

    private final Random random = new Random();

    /**
     * Genera N lecturas de sensores con enriquecimiento climático.
     */
    public List<SensorReading> generateBatch(int count) {
        List<SensorReading> readings = new ArrayList<>();
        String batchId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        for (int i = 0; i < count; i++) {
            long start = System.currentTimeMillis();
            SensorReading reading = generateSingle(batchId, i);
            long latency = System.currentTimeMillis() - start;

            reading.setIngestionLatencyMs(latency);
            latencies.add(latency);
            if (latencies.size() > 1000) latencies.remove(0);

            readings.add(reading);
            totalGenerated.incrementAndGet();
            if (reading.getAnomalyDetected() != null && reading.getAnomalyDetected()) {
                totalAlertas.incrementAndGet();
            }
        }

        log.info("[Simulator] Batch {} generado: {} lecturas — anomalías: {}",
                batchId, count, readings.stream().filter(r -> Boolean.TRUE.equals(r.getAnomalyDetected())).count());
        return readings;
    }

    private SensorReading generateSingle(String batchId, int index) {
        ReservaConfig reserva = RESERVAS.get(random.nextInt(RESERVAS.size()));

        // Variación geográfica pequeña por sensor
        double lat = reserva.lat() + (random.nextDouble() - 0.5) * 0.05;
        double lon = reserva.lon() + (random.nextDouble() - 0.5) * 0.05;

        // Datos raw del sensor
        double temperature  = 15.0 + random.nextDouble() * 35.0;
        double humidity     = 20.0 + random.nextDouble() * 65.0;
        double co2          = 350.0 + random.nextDouble() * 300.0;
        double windSpeed    = random.nextDouble() * 20.0;
        double windDir      = random.nextDouble() * 360.0;

        // Simular condición de incendio ocasional (5% de probabilidad)
        boolean simulateFireCondition = random.nextDouble() < 0.05;
        if (simulateFireCondition) {
            temperature = 70.0 + random.nextDouble() * 20.0;
            humidity    = 5.0  + random.nextDouble() * 15.0;
            co2         = 800.0 + random.nextDouble() * 200.0;
            windSpeed   = 15.0 + random.nextDouble() * 15.0;
        }

        String deviceId = String.format("SNS-%s-%03d", reserva.shortCode(), index + 1);

        SensorReading reading = SensorReading.builder()
                .deviceId(deviceId)
                .zone(reserva.zona())
                .reserva(reserva.nombre())
                .sensorType(randomSensorType())
                .temperature(round2(temperature))
                .humidity(round2(humidity))
                .co2Ppm(round2(co2))
                .windSpeedMs(round2(windSpeed))
                .windDirectionDeg(round2(windDir))
                .latitude(round4(lat))
                .longitude(round4(lon))
                .gpsHashId(pseudonimizarGPS(lat, lon))
                .timestamp(Instant.now())
                .layer("BRONZE")
                .batchId(batchId)
                .build();

        // Enriquecimiento con Open-Meteo
        enrichWithWeather(reading, lat, lon, reserva.nombre());

        // Cálculo de riesgo
        riskCalculator.calculate(reading);

        return reading;
    }

    private void enrichWithWeather(SensorReading reading, double lat, double lon, String cacheKey) {
        CachedWeather cached = weatherCache.get(cacheKey);
        OpenMeteoResponse response;

        if (cached != null && !cached.isExpired()) {
            response = cached.response();
            log.debug("[OpenMeteo] Cache hit para {}", cacheKey);
        } else {
            log.info("[OpenMeteo] Consultando clima para {} ({}, {})", cacheKey, lat, lon);
            response = openMeteoClient.getWeather(lat, lon);
            if (response != null) {
                weatherCache.put(cacheKey, new CachedWeather(response, System.currentTimeMillis()));
            }
        }

        if (response != null && response.getCurrent() != null) {
            var curr = response.getCurrent();
            reading.setWeatherTemp(curr.getTemperature2m());
            reading.setWeatherHumidity(curr.getRelativeHumidity2m() != null
                    ? curr.getRelativeHumidity2m().doubleValue() : null);
            reading.setWeatherWindSpeed(curr.getWindSpeed10m());
            reading.setWeatherPrecipitation(curr.getPrecipitation());
            reading.setWeatherCode(curr.getWeatherCode());
            reading.setWeatherDescription(weatherCodeMapper.describe(curr.getWeatherCode()));
            reading.setApparentTemperature(curr.getApparentTemperature());
            reading.setSoilMoisture(curr.getSoilMoisture0to1cm());
        } else {
            log.warn("[OpenMeteo] Sin datos para {} — usando solo datos del sensor", cacheKey);
            reading.setWeatherDescription("Sin datos climáticos");
        }
    }

    /**
     * Pseudonimiza coordenadas GPS con SHA-256 + salt (cumplimiento GDPR).
     * Solo la capa BRONZE conserva lat/lon reales.
     */
    private String pseudonimizarGPS(double lat, double lon) {
        try {
            String salt = "WG_2026_SALT_RESERVAS";
            String input = String.format("%.6f:%.6f:%s", lat, lon, salt);
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b));
            return "GPS_" + hex.substring(0, 16).toUpperCase();
        } catch (Exception e) {
            return "GPS_UNKNOWN";
        }
    }

    private String randomSensorType() {
        String[] types = {"TEMPERATURE", "HUMIDITY", "CO2", "WIND", "CAMERA_TRAP", "GPS"};
        return types[random.nextInt(types.length)];
    }

    private double round2(double v) { return Math.round(v * 100.0) / 100.0; }
    private double round4(double v) { return Math.round(v * 10000.0) / 10000.0; }

    // --- Métricas públicas ---
    public long getTotalGenerated()  { return totalGenerated.get(); }
    public long getTotalAlertas()    { return totalAlertas.get(); }

    public double getAvgLatencyMs() {
        if (latencies.isEmpty()) return 0;
        return latencies.stream().mapToLong(Long::longValue).average().orElse(0);
    }

    public double getP95LatencyMs() {
        if (latencies.isEmpty()) return 0;
        List<Long> sorted = new ArrayList<>(latencies);
        Collections.sort(sorted);
        int idx = (int) Math.ceil(sorted.size() * 0.95) - 1;
        return sorted.get(Math.max(0, idx));
    }

    // --- Records internos ---
    private record ReservaConfig(String nombre, String zona, double lat, double lon) {
        String shortCode() { return nombre.replaceAll("[^A-Z]", "").substring(0, Math.min(3, nombre.replaceAll("[^A-Z]","").length())); }
    }

    private record CachedWeather(OpenMeteoResponse response, long timestamp) {
        boolean isExpired() { return System.currentTimeMillis() - timestamp > CACHE_TTL_MS; }
    }

    private static final long CACHE_TTL_MS = 10 * 60 * 1000L;
}
