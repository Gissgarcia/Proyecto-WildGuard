package com.wildguard.config;

import com.wildguard.model.SensorReading;
import com.wildguard.service.SensorSimulatorService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * API REST del Sensor Simulator.
 * Permite disparar simulaciones manualmente y consultar métricas.
 *
 * BASE URL: http://localhost:8080/api/v1/simulator
 */
@RestController
@RequestMapping("/api/v1/simulator")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class SensorController {

    private final SensorSimulatorService simulatorService;

    /**
     * GET /api/v1/simulator/health
     * Health check básico.
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "sensor-simulator",
                "version", "1.0.0"
        ));
    }

    /**
     * GET /api/v1/simulator/generate?count=10
     * Genera N lecturas de sensores con clima real de Open-Meteo.
     */
    @GetMapping("/generate")
    public ResponseEntity<List<SensorReading>> generate(
            @RequestParam(defaultValue = "5") int count) {
        if (count < 1 || count > 100) {
            return ResponseEntity.badRequest().build();
        }
        List<SensorReading> readings = simulatorService.generateBatch(count);
        return ResponseEntity.ok(readings);
    }

    /**
     * GET /api/v1/simulator/generate/single
     * Genera exactamente 1 lectura de sensor.
     */
    @GetMapping("/generate/single")
    public ResponseEntity<SensorReading> generateSingle() {
        List<SensorReading> readings = simulatorService.generateBatch(1);
        return ResponseEntity.ok(readings.get(0));
    }

    /**
     * GET /api/v1/simulator/metrics
     * Métricas operacionales del simulador.
     */
    @GetMapping("/metrics")
    public ResponseEntity<Map<String, Object>> metrics() {
        return ResponseEntity.ok(Map.of(
                "totalGenerated",  simulatorService.getTotalGenerated(),
                "totalAlertas",    simulatorService.getTotalAlertas(),
                "avgLatencyMs",    String.format("%.2f", simulatorService.getAvgLatencyMs()),
                "p95LatencyMs",    String.format("%.2f", simulatorService.getP95LatencyMs()),
                "alertRate",       simulatorService.getTotalGenerated() > 0
                        ? String.format("%.2f%%", (simulatorService.getTotalAlertas() * 100.0)
                            / simulatorService.getTotalGenerated())
                        : "0%"
        ));
    }
}
