package com.wildguard.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;

/**
 * Representa un evento de lectura de sensor IoT.
 * Campos combinados: datos propios del sensor + enriquecimiento Open-Meteo.
 */
@Data
@Builder
public class SensorReading {

    // --- Identificación ---
    private String deviceId;
    private String zone;
    private String reserva;
    private String sensorType; // TEMPERATURE, HUMIDITY, CO2, WIND, CAMERA

    // --- Datos del sensor (raw) ---
    private Double temperature;     // °C
    private Double humidity;        // %
    private Double co2Ppm;          // ppm
    private Double windSpeedMs;     // m/s
    private Double windDirectionDeg;

    // --- Geolocalización (pseudonimizada tras Lambda) ---
    private String gpsHashId;       // hash+salt — nunca coordenadas en claro en Silver/Gold
    private Double latitude;        // solo capa Bronze
    private Double longitude;       // solo capa Bronze

    // --- Enriquecimiento Open-Meteo (datos climáticos reales) ---
    private Double weatherTemp;          // temperatura real de la API
    private Double weatherHumidity;      // humedad real
    private Double weatherWindSpeed;     // viento real (km/h)
    private Double weatherPrecipitation; // precipitación mm/h
    private Integer weatherCode;         // WMO weather code
    private String weatherDescription;   // descripción legible
    private Double apparentTemperature;  // sensación térmica
    private Double soilMoisture;         // humedad suelo estimada

    // --- Inferencia de riesgo ---
    private RiskLevel riskLevel;   // LOW, MEDIUM, HIGH, CRITICAL
    private Double riskScore;      // 0.0 – 1.0
    private Boolean anomalyDetected;

    // --- Metadata del pipeline ---
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant timestamp;
    private String layer;           // BRONZE / SILVER / GOLD
    private Long ingestionLatencyMs;
    private String batchId;

    public enum RiskLevel {
        LOW, MEDIUM, HIGH, CRITICAL
    }
}
