package com.wildguard.service;

import com.wildguard.model.SensorReading;
import com.wildguard.model.SensorReading.RiskLevel;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Calcula nivel de riesgo de incendio combinando:
 * - Datos del sensor IoT (temperatura, CO2, viento, humedad)
 * - Datos climáticos reales de Open-Meteo
 *
 * Basado en índice FWI (Fire Weather Index) simplificado.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RiskCalculator {

    private final WeatherCodeMapper weatherCodeMapper;

    /**
     * Calcula riskScore (0.0–1.0) y RiskLevel para un reading.
     * Modifica el reading in-place y lo retorna.
     */
    public SensorReading calculate(SensorReading reading) {
        double score = 0.0;

        // --- Factor temperatura sensor (peso 30%) ---
        double temp = orDefault(reading.getTemperature(), 25.0);
        double tempFactor = normalize(temp, 10.0, 80.0);
        score += tempFactor * 0.30;

        // --- Factor humedad relativa (peso 20%) — inverso ---
        double hum = orDefault(reading.getHumidity(), 50.0);
        double humFactor = 1.0 - normalize(hum, 10.0, 100.0);
        score += humFactor * 0.20;

        // --- Factor CO2 (peso 15%) ---
        double co2 = orDefault(reading.getCo2Ppm(), 400.0);
        double co2Factor = normalize(co2, 300.0, 1000.0);
        score += co2Factor * 0.15;

        // --- Factor viento sensor (peso 15%) ---
        double wind = orDefault(reading.getWindSpeedMs(), 0.0);
        double windFactor = normalize(wind, 0.0, 30.0);
        score += windFactor * 0.15;

        // --- Factor climático Open-Meteo (peso 20%) ---
        double weatherFactor = calcWeatherFactor(reading);
        score += weatherFactor * 0.20;

        // Ajuste: precipitación anula el riesgo
        Double precip = reading.getWeatherPrecipitation();
        if (precip != null && precip > 1.0) {
            score *= Math.max(0.0, 1.0 - (precip / 10.0));
        }

        double finalScore = Math.min(1.0, Math.max(0.0, score));

        reading.setRiskScore(Math.round(finalScore * 1000.0) / 1000.0);
        reading.setRiskLevel(toLevel(finalScore));
        reading.setAnomalyDetected(finalScore >= 0.75 || temp > 65.0);

        log.debug("[Risk] {} → score={} level={}", reading.getDeviceId(), finalScore, reading.getRiskLevel());
        return reading;
    }

    private double calcWeatherFactor(SensorReading r) {
        double factor = 0.0;
        int count = 0;

        if (r.getWeatherTemp() != null) {
            factor += normalize(r.getWeatherTemp(), 5.0, 45.0);
            count++;
        }
        if (r.getWeatherHumidity() != null) {
            factor += 1.0 - normalize(r.getWeatherHumidity(), 10.0, 100.0);
            count++;
        }
        if (r.getWeatherWindSpeed() != null) {
            factor += normalize(r.getWeatherWindSpeed(), 0.0, 25.0);
            count++;
        }
        if (r.getWeatherCode() != null) {
            factor += weatherCodeMapper.riskMultiplier(r.getWeatherCode());
            count++;
        }

        return count > 0 ? factor / count : 0.5;
    }

    private double normalize(double value, double min, double max) {
        if (max <= min) return 0.0;
        return Math.min(1.0, Math.max(0.0, (value - min) / (max - min)));
    }

    private double orDefault(Double value, double fallback) {
        return value != null ? value : fallback;
    }

    private RiskLevel toLevel(double score) {
        if (score >= 0.80) return RiskLevel.CRITICAL;
        if (score >= 0.60) return RiskLevel.HIGH;
        if (score >= 0.35) return RiskLevel.MEDIUM;
        return RiskLevel.LOW;
    }
}
