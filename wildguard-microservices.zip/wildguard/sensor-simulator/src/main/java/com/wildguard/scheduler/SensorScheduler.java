package com.wildguard.scheduler;

import com.wildguard.model.SensorReading;
import com.wildguard.service.SensorSimulatorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

/**
 * Scheduler que emite lecturas de sensores automáticamente
 * y las envía al ingestion-service.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SensorScheduler {

    private final SensorSimulatorService simulatorService;
    private final WebClient.Builder webClientBuilder;

    @Value("${wildguard.simulator.sensors-per-tick:5}")
    private int sensorsPerTick;

    @Value("${wildguard.simulator.enabled:true}")
    private boolean enabled;

    @Value("${wildguard.ingestion.url:http://localhost:8081}")
    private String ingestionUrl;

    /**
     * Emisión principal cada 5 segundos.
     * Simula el ciclo de recolección de datos de sensores IoT.
     */
    @Scheduled(fixedDelayString = "${wildguard.simulator.interval-ms:5000}")
    public void emitSensorData() {
        if (!enabled) return;

        List<SensorReading> readings = simulatorService.generateBatch(sensorsPerTick);

        readings.forEach(r -> {
            log.info("[Tick] {} | Zona: {} | Temp: {}°C | Riesgo: {} ({}) | Clima: {}",
                    r.getDeviceId(),
                    r.getZone(),
                    r.getTemperature(),
                    r.getRiskLevel(),
                    r.getRiskScore(),
                    r.getWeatherDescription());

            if (Boolean.TRUE.equals(r.getAnomalyDetected())) {
                log.warn("🔥 [ANOMALÍA] {} — Temp={}°C Score={} — Enviando alerta SNS",
                        r.getDeviceId(), r.getTemperature(), r.getRiskScore());
            }
        });

        // Enviar al ingestion-service (no-bloqueante, fire-and-forget)
        try {
            webClientBuilder.build()
                    .post()
                    .uri(ingestionUrl + "/api/v1/ingest/batch")
                    .bodyValue(readings)
                    .retrieve()
                    .toBodilessEntity()
                    .subscribe(
                        resp -> log.debug("[Ingestion] Batch enviado OK — status={}", resp.getStatusCode()),
                        err  -> log.warn("[Ingestion] Error enviando batch: {}", err.getMessage())
                    );
        } catch (Exception e) {
            log.warn("[Ingestion] Servicio no disponible — datos procesados localmente");
        }
    }

    /**
     * Reporte de métricas cada 60 segundos.
     */
    @Scheduled(fixedDelay = 60_000)
    public void reportMetrics() {
        log.info("=== [MÉTRICAS WildGuard] Total generados: {} | Alertas: {} | Lat avg: {}ms | P95: {}ms ===",
                simulatorService.getTotalGenerated(),
                simulatorService.getTotalAlertas(),
                String.format("%.1f", simulatorService.getAvgLatencyMs()),
                String.format("%.1f", simulatorService.getP95LatencyMs()));
    }
}
