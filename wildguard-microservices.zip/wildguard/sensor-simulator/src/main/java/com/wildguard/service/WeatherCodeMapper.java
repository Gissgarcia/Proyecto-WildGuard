package com.wildguard.service;

import org.springframework.stereotype.Component;

/**
 * Convierte códigos WMO (World Meteorological Organization) de Open-Meteo
 * a descripciones legibles en español.
 */
@Component
public class WeatherCodeMapper {

    public String describe(Integer code) {
        if (code == null) return "Desconocido";
        return switch (code) {
            case 0  -> "Cielo despejado";
            case 1  -> "Principalmente despejado";
            case 2  -> "Parcialmente nublado";
            case 3  -> "Nublado";
            case 45 -> "Niebla";
            case 48 -> "Niebla con escarcha";
            case 51 -> "Llovizna ligera";
            case 53 -> "Llovizna moderada";
            case 55 -> "Llovizna densa";
            case 61 -> "Lluvia ligera";
            case 63 -> "Lluvia moderada";
            case 65 -> "Lluvia intensa";
            case 71 -> "Nevada ligera";
            case 73 -> "Nevada moderada";
            case 75 -> "Nevada intensa";
            case 80 -> "Chubascos ligeros";
            case 81 -> "Chubascos moderados";
            case 82 -> "Chubascos violentos";
            case 95 -> "Tormenta eléctrica";
            case 96, 99 -> "Tormenta con granizo";
            default -> "Código " + code;
        };
    }

    /**
     * Retorna el factor de riesgo climático adicional según el código WMO.
     * 0.0 = sin riesgo adicional, 1.0 = riesgo máximo (condiciones extremas).
     */
    public double riskMultiplier(Integer code) {
        if (code == null) return 0.0;
        return switch (code) {
            case 0  -> 0.4;  // Cielo despejado → alto riesgo de incendio
            case 1  -> 0.3;
            case 2  -> 0.2;
            case 3  -> 0.1;
            case 45, 48 -> 0.05;
            case 51, 53, 55, 61, 63, 65 -> 0.0; // Lluvia → sin riesgo
            case 71, 73, 75 -> 0.0;
            case 80, 81, 82 -> 0.0;
            case 95, 96, 99 -> 0.05;
            default -> 0.1;
        };
    }
}
