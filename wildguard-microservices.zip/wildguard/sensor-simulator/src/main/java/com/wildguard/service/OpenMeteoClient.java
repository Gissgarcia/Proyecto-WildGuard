package com.wildguard.service;

import com.wildguard.model.OpenMeteoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;

/**
 * Cliente HTTP reactivo para la API pública Open-Meteo.
 * Sin API key — completamente gratuita.
 * Docs: https://open-meteo.com/en/docs
 */
@Slf4j
@Service
public class OpenMeteoClient {

    private static final String BASE_URL = "https://api.open-meteo.com/v1/forecast";
    private static final Duration TIMEOUT = Duration.ofSeconds(10);

    private final WebClient webClient;

    public OpenMeteoClient(WebClient.Builder builder) {
        this.webClient = builder
                .baseUrl(BASE_URL)
                .defaultHeader("Accept", "application/json")
                .build();
    }

    /**
     * Obtiene condiciones climáticas actuales para coordenadas dadas.
     * Retorna null en caso de error para no bloquear el pipeline.
     */
    public OpenMeteoResponse getWeather(double latitude, double longitude) {
        try {
            return webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .queryParam("latitude", latitude)
                            .queryParam("longitude", longitude)
                            .queryParam("current",
                                    "temperature_2m",
                                    "relative_humidity_2m",
                                    "apparent_temperature",
                                    "precipitation",
                                    "weather_code",
                                    "wind_speed_10m",
                                    "wind_direction_10m",
                                    "soil_moisture_0_to_1cm")
                            .queryParam("timezone", "America/Santiago")
                            .queryParam("wind_speed_unit", "ms")
                            .build())
                    .retrieve()
                    .bodyToMono(OpenMeteoResponse.class)
                    .timeout(TIMEOUT)
                    .doOnError(e -> log.warn("[OpenMeteo] Error al consultar clima: {}", e.getMessage()))
                    .onErrorReturn(new OpenMeteoResponse())
                    .block();
        } catch (Exception e) {
            log.error("[OpenMeteo] Falla crítica: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Versión reactiva (no-bloqueante) para uso en flujos reactivos.
     */
    public Mono<OpenMeteoResponse> getWeatherReactive(double latitude, double longitude) {
        return webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .queryParam("latitude", latitude)
                        .queryParam("longitude", longitude)
                        .queryParam("current",
                                "temperature_2m",
                                "relative_humidity_2m",
                                "apparent_temperature",
                                "precipitation",
                                "weather_code",
                                "wind_speed_10m",
                                "wind_direction_10m",
                                "soil_moisture_0_to_1cm")
                        .queryParam("timezone", "America/Santiago")
                        .queryParam("wind_speed_unit", "ms")
                        .build())
                .retrieve()
                .bodyToMono(OpenMeteoResponse.class)
                .timeout(TIMEOUT)
                .doOnError(e -> log.warn("[OpenMeteo] Error reactivo: {}", e.getMessage()))
                .onErrorReturn(new OpenMeteoResponse());
    }
}
