package com.wildguard.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Validation Service — equivalente a AWS Lambda de validación y pseudonimización.
 * Transforma BRONZE → SILVER:
 * - Valida esquema JSON
 * - Normaliza tipos
 * - Deduplica (por deviceId + timestamp)
 * - Pseudonimiza GPS
 * - Enriquece con metadatos de pipeline
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/validate")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class ValidationController {

    private final ObjectMapper mapper = new ObjectMapper().findAndRegisterModules();
    private final AtomicLong validated = new AtomicLong(0);
    private final AtomicLong rejected  = new AtomicLong(0);
    private final Set<String> dedupeCache = Collections.synchronizedSet(new LinkedHashSet<>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry eldest) {
            return size() > 5000; // max 5000 hashes en cache
        }
    });

    private static final List<String> REQUIRED_FIELDS = List.of(
            "deviceId", "temperature", "humidity", "timestamp", "zone"
    );

    /**
     * POST /api/v1/validate/process
     * Procesa un batch de eventos Bronze → Silver.
     */
    @PostMapping("/process")
    public ResponseEntity<Map<String, Object>> process(@RequestBody List<JsonNode> events) {
        List<JsonNode> silver = new ArrayList<>();
        List<Map<String, Object>> errors = new ArrayList<>();

        for (JsonNode event : events) {
            ValidationResult result = validateAndTransform(event);
            if (result.valid()) {
                silver.add(result.transformed());
                validated.incrementAndGet();
            } else {
                errors.add(Map.of("deviceId", getStr(event, "deviceId"), "reason", result.error()));
                rejected.incrementAndGet();
                log.warn("[Lambda] RECHAZADO {}: {}", getStr(event, "deviceId"), result.error());
            }
        }

        log.info("[Lambda] Procesados: {} válidos, {} rechazados", silver.size(), errors.size());

        return ResponseEntity.ok(Map.of(
                "layer",     "SILVER",
                "accepted",  silver.size(),
                "rejected",  errors.size(),
                "records",   silver,
                "errors",    errors
        ));
    }

    /**
     * GET /api/v1/validate/metrics
     */
    @GetMapping("/metrics")
    public ResponseEntity<Map<String, Object>> metrics() {
        long total = validated.get() + rejected.get();
        return ResponseEntity.ok(Map.of(
                "totalProcessed", total,
                "validated",  validated.get(),
                "rejected",   rejected.get(),
                "validationRate", total > 0
                        ? String.format("%.2f%%", validated.get() * 100.0 / total)
                        : "N/A",
                "dedupeCache", dedupeCache.size()
        ));
    }

    private ValidationResult validateAndTransform(JsonNode node) {
        // 1. Campos requeridos
        for (String field : REQUIRED_FIELDS) {
            if (!node.has(field) || node.get(field).isNull()) {
                return ValidationResult.fail("Campo requerido ausente: " + field);
            }
        }

        // 2. Rango de temperatura
        double temp = node.get("temperature").asDouble();
        if (temp < -60 || temp > 200) {
            return ValidationResult.fail("Temperatura fuera de rango: " + temp);
        }

        // 3. Deduplicación
        String dedupeKey = getStr(node, "deviceId") + "|" + getStr(node, "timestamp");
        if (dedupeCache.contains(dedupeKey)) {
            return ValidationResult.fail("Evento duplicado");
        }
        dedupeCache.add(dedupeKey);

        // 4. Transformar a Silver (pseudonimizar + normalizar)
        ObjectNode silver = mapper.createObjectNode();
        silver.put("deviceId",    getStr(node, "deviceId"));
        silver.put("zone",        getStr(node, "zone"));
        silver.put("reserva",     getStr(node, "reserva"));
        silver.put("sensorType",  getStr(node, "sensorType"));

        // Datos normalizados
        silver.put("temperature",    round(node.path("temperature").asDouble(), 2));
        silver.put("humidity",       round(node.path("humidity").asDouble(), 2));
        silver.put("co2Ppm",         round(node.path("co2Ppm").asDouble(), 2));
        silver.put("windSpeedMs",    round(node.path("windSpeedMs").asDouble(), 2));

        // GPS pseudonimizado
        silver.put("gpsHashId",   getStr(node, "gpsHashId"));
        // lat/lon NO se copian a Silver — solo Bronze las contiene

        // Clima real Open-Meteo
        if (node.has("weatherTemp") && !node.get("weatherTemp").isNull()) {
            silver.put("weatherTemp",          node.get("weatherTemp").asDouble());
            silver.put("weatherHumidity",      node.path("weatherHumidity").asDouble());
            silver.put("weatherWindSpeed",     node.path("weatherWindSpeed").asDouble());
            silver.put("weatherPrecipitation", node.path("weatherPrecipitation").asDouble());
            silver.put("weatherCode",          node.path("weatherCode").asInt());
            silver.put("weatherDescription",   getStr(node, "weatherDescription"));
            silver.put("apparentTemperature",  node.path("apparentTemperature").asDouble());
        }

        // Inferencia de riesgo
        silver.put("riskLevel",       getStr(node, "riskLevel"));
        silver.put("riskScore",       round(node.path("riskScore").asDouble(), 3));
        silver.put("anomalyDetected", node.path("anomalyDetected").asBoolean());

        // Metadatos pipeline
        silver.put("_layer",          "SILVER");
        silver.put("_processedAt",    Instant.now().toString());
        silver.put("_originalLayer",  "BRONZE");
        silver.put("timestamp",       getStr(node, "timestamp"));
        silver.put("batchId",         getStr(node, "batchId"));

        return ValidationResult.ok(silver);
    }

    private String getStr(JsonNode node, String field) {
        return node.has(field) && !node.get(field).isNull() ? node.get(field).asText() : "";
    }

    private double round(double v, int decimals) {
        double factor = Math.pow(10, decimals);
        return Math.round(v * factor) / factor;
    }

    private record ValidationResult(boolean valid, JsonNode transformed, String error) {
        static ValidationResult ok(JsonNode t)       { return new ValidationResult(true,  t,    null); }
        static ValidationResult fail(String reason)  { return new ValidationResult(false, null, reason); }
    }
}
